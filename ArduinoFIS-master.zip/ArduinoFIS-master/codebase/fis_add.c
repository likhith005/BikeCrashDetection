FIS_TYPE fis_add(FIS_TYPE a, FIS_TYPE b)
{
    return (a + b);
}